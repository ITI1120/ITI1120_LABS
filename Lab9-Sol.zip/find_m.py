def find_m(l, v):
  '''(list, int) -> bool
  Returns True if v is in the lists, False otherwise" 
  '''
  NSteps = 0
  find = False
  for row_val in l:
    if find:
      break
    for col_val in row_val:
      NSteps += 1
      if col_val == v:
          find = True
          break
  print("Number of steps", NSteps)      
  return find

N = 100


l1 = [ [1,2,3, 12], [4,5,6], [8,9, 7]]
print(l1)
print(find_m(l1, 8))
      

