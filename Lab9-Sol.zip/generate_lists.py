import random

N = 100000

# list in ascending order from 1 to N
l1 = [ v for v in range(1, N+1) ]
print(l1)

# list in descending order from N to 1
l2 = [ v for v in range(N, 0, -1) ]
print(l2)

# list with random elements
l3 = []
for i in range(N):
  v = random.randrange(1,N+1)
  l3.append(v)
print(l3)  
