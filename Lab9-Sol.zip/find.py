import random

def find(l, v):
  '''(list, int) -> bool
  Returns True if v is in the list, False otherwise" 
  '''
  NSteps = 0
  find = False
  for val in l:
      NSteps += 1
      if val == v:
          find = True
          break
  print("Number of steps", NSteps)      
  return find

N = 100

# list in ascending order from 1 to N
l1 = [ v for v in range(1, N+1) ]
print(l1)
print(find(l1, 78))
      
# list with random elements
l3 = []
for i in range(N):
  v = random.randrange(1,N+1)
  l3.append(v)
print(l3)
print(find(l3, 78))
