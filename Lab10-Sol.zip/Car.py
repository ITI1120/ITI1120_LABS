﻿class car(object):
    def __init__(self, brand = 'Ford', color = 'red'):
        self.color = color
        self.brand = brand
        self.driver = 'person'
        self.speed = 0
        
    def accelerate(self, rate, duration):
        if self.driver =='person':
            print("This car does not have a driver!")
        else:    
            self.speed = self.speed + rate * duration
        
    def choice_driver(self, name):
        self.driver = name  
        
    def display_all(self):
        print("{} {} driven by {}, speed = {} m/s".\
            format(self.brand, self.color, self.driver, self.speed))
    def __repr__(self):
       return self.brand +" "+self.color+" driven by "+self.driver +" speed = "+str(self.speed)+" m/s"
    
    def __eq__(self, other):
        return self.brand == other.brand and self.color == other.color 
    
a1 = car('Peugeot', 'blue')
a2 = car(col0r = 'green')
a3 = car('Mercedes')
a1.choice_driver('Roméo')
a2.choice_driver('Juliette')
a2.accelerate(1.8, 12)
a3.accelerate(1.9, 11)
a2.display_all()
a3.display_all()
