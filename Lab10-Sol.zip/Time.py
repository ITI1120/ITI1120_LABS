class Time:
  '''class temporal'''

  def __init__(self, h=12, m=0, s=0):
    '''(Time)-> None'''
    self.hour = h
    self.minute = m
    self.second = s

  def setTime(self, h, m=0, s=0):
    '''(Time)-> None'''        
    self.hour = h 
    self.minute = m
    self.second = s

  def display_hour(self):
    '''(Time)-> None'''
    print("{0}:{1}:{2}".format(self.hour, self.minute, self.second)) 

  def __repr__(self):
    '''(Time)-> str'''
    return (str(self.hour) +":" +str(self.minute) +":" +str(self.second))

  def __eq__(self, other):
    '''(Time)-> bool'''
    return self.hour == other.hour and self.minute == other.minute and self.second == other.second
  
