﻿class Time:
  '''class temporal'''

  def __init__(self, h=12, m=0, s=0):
    '''(Time)-> None'''
    self.hour = h
    self.minute = m
    self.second = s
    self.setTime(h,m,s)

  def setTime(self, h, m=0, s=0):
    '''(Time)-> None'''
    if ( s > 59 ):
           m = m + s // 60  # Look for number of minutes to add
           s = s % 60      # put back the seconds to the interval [0,59]
    if ( m > 59 ):
           h = h + m // 60  # Look for number of minutes to addr
           m = m % 60       # put back the minutes to the interval [0,59]
           
    self.hour = h % 24   # put back the hours to the interval [0,23]
    self.minute = m
    self.second = s

  def display_hour(self):
    '''(Time)-> None'''
    print("{0}:{1}:{2}".format(self.hour, self.minute, self.second)) 

  def __repr__(self):
    '''(Time)-> str'''
    return (str(self.hour) +":" +str(self.minute) +":" +str(self.second))

  def __eq__(self, other):
    '''(Time)-> bool'''
    return self.hour == other.hour and self.minute == other.minute and self.second == other.second

  def estAvant(self, t2):
     '''(Time) -> bool 
     reurns True if the Time represented by self is before the Time of t2,
     or False otherwise'''
     before =  self.hour < t2.hour or (self.hour == t2.hour and self.minute < t2.minute) or (self.hour == t2.hour and self.minute == t2.minute and self.second < t2.second)
     return before

  def duration(self, t2):
     ''' (Time) -> Time
     returns a new object Time with the number of hours, minutes and seconds between self and t2'''
     if self.isBefore(t2):
         diffS = 60*60*(t2.hour - self.hour) + 60*(t2.minute - self.minute) + (t2.second - self.second)
     else: 
         diffS = 60*60*(self.hour - t2.hour) + 60*(self.minute - t2.minute) + (self.second - t2.second)
     result = Time()
     result.setTime(0, 0, diffS) # Calculate the number of hours
     return result
