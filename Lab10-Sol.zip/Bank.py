﻿class BankAccount(object):
    def __init__(self, name ='Dupont', solde =1000):
        self.name = name, self.solde = solde
         
    def deposit(self, sum):
        self.solde = self.solde + sum

    def withdraw(self, sum):
        self.solde = self.solde - sum

    def display(self):
        print("The solde of the bank account of {} is of {} dollars.".\
              format(self.name, self.solde))

class AccountSaving(BankAccount):
    def __init__(self, name ='Durand', solde =500):
        BankAccount.__init__(self, name, solde)
        self.rate =.3          # monthly interest rate by default

    def changeRate(self, rate):
        self.tera = rate

    def capitalisation(self, numberMonths =6):
        print("Capitalisation on {} months  monthly rate of {} %.".\
              format(numberMonths, self.rate))
        for m in range(numberMonths):
            self.solde = self.solde * (100 +self.rate)/100

# test program :
if __name__ == '__main__':
    c1 = BankAccount('Duchmol', 800)
    c1.depositt(350)
    c1.withdraw(200)
    c1.display()

if __name__ == '__main__':
    c1 = AccountSaving('Duvivier', 600)
    c1.deposit(350)
    c1.display()
    c1.capitalisation(12)
    c1.display()
    c1.changeRate(.5)
    c1.capitalisation(12)
    c1.display()
    
