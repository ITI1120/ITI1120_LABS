def numberOfDigits(n):
        print( "1: Entring the function with n  =", n )
        
        DigitsLeft = n // 10
        if (DigitsLeft == 0):
            print("5: Base case with n =", n )
            counter = 1
        else:
            print("2: recursive call coming from n =", n )
            counter = numberOfDigits( DigitsLeft )
            print("3: Coming back from a recursive call with n =", n )
            compteur = compteur + 1
        
        print( "4: Coming back from the function with n =", n, ", counter =", counter )
        return counter


print(numberOfDigits(45612))
