def initList(L, n):
    if n != 0:
      initList( L, n-1 )        
      L.append(n-1)

n = int(input("Please enter n: "))
L = []
initList(L, n)
print(L)
