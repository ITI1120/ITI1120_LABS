def verifySort(a, n):
    '''(list, int) -> bool
    Verify if the list is sorted. n is the size of the list
    '''
    if a[n-2] <= a[n-1] :
       if  n == 2 :
            sorted = True
       else:
            sorted = vérifySorted(a, n-1)
    else:
       sorted = False

    return sorted

