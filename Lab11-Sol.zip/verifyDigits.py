def verifyDigits( a, n):
    ''' (list, int) -> bool
    a is a list of size n
    '''
    if ( n == 0 ):
        allDigits = True
    else:    
        if a[n-1] >= 0 and a[n-1] <= 9 :
           allDigits = verifyDigits( a, n-1 )
        else:
            allDigits = False
    return allDigits 
