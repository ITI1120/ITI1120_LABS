def bcd(x, y):
        if (x % y == 0):
           res = y
        else: 
           res = bcd(y, x % y)
        return res
    
