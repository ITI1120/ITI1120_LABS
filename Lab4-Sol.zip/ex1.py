counter = 10
while(counter >= 0):
  print(counter)
  counter = counter + 1
