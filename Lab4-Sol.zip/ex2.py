# print 1 2  ... n


n = int(input("Please enter n "))

i = 1   
while i<= n:
   print(i, end = " ")
   i += 1
