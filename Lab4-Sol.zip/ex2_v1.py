# display 1 2  ... n

def display(n):
 i = 1   
 while i<= n:
   print(i, end = " ")
   i += 1

n = int(input("Please enter n "))
display(n) 
 
