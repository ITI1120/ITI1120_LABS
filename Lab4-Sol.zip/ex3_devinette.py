# Guessing Game
import random

def guess(n):
    # INTERMÉDIARY VARIABLES
    nbrguessed = 0  # the gueesed number by the user
                    # initialized with an invalid value in the game 
    # RESULT VARIABLE
    tries = 1
    while(nbrguessed != n):
      nbrguessed = int(input("Please. guess the number: "))     
      if(nbrguessed != n):
        tries = tries + 1;
        if(nbrguessed > n):
            print("Too high")
        else:
            print("Too low")
    # RETURN THE RESULT
    return(tries)


n = random.randrange(1,11)
#n = random.randint(1, 10) 
#print(n)

# CALL TO THE METHOD of THE PROBLEM RESOLUTION
nbrguessed = guess(n)
# DISPLAY OF RESULTS AND MODIFICATION IN THE SCREEN
print("Bravo! You have found the number in", nbrguessed,"tries.")
