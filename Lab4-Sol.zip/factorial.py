# factorial 1 * 2 * ... * n
# 0! = 1
# with functions

def getFact(n):
 fact = 1
 counter = 1
 while counter <= n:
  fact = fact * counter
  counter = counter + 1
 return(fact)

n = -1 
while(n < 0):
 n = int(input("Please enter n, a non negative integer: "))
 if (n < 0):
   print("n must be non negative")

print('The factorial is', getFact(n)) 
 
