def move_zeros_with_return(lst):
     '''lst -> lst
        Returns a new list with the zeros of lst at the end
        Precondtion: lst is a list of numbers
     '''
     tmp=[0]*len(lst) #tmp is filled with zeros
     index_tmp=0
     for i in range(len(lst)):
          if(lst[i]!=0):
               tmp[index_tmp]=lst[i]
               index_tmp=index_tmp+1
          
     # we are done because tmp already had zeros
     return tmp

x = [1, 0, 3, 0, 0, 5, 7] 
print(x)
y=move_zeros_with_return(x)
print(x,y)

# if we try the following, x changes because x takes
# the value of the reference to the new list
x=move_zeros_with_return(x) 
print(x)          
