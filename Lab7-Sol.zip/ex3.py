def sum_of_three(x):
     '''(tuple)->bool
     Returns True if the sum of 3 consecutive elements is zero
     Precondition: the tuple has at least 3 elements
     >>> t = (1,2,-3,4,-1,3)
     >>> sum_of_three(t)
     True
     '''
     res = False
     i = 0
     sum = 0
     while (i < len(x) - 2):
       sum = sum + x[i] + x[i+1] + x[i+2]
       if (sum == 0):
         res = True
         break
       i = i + 1
     return res

t = (1,2,-3,4,-1,3)
print(sum_of_three(t))


     
