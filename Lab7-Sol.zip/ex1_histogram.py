def histogram(text):
   letters ={}
   for c in text:
      letters[c] = letters.get(c, 0) + 1
   return letters

t = "bonjour"
d = histogram(t)
letters_sorted = list(d.items())
letters_sorted.sort()
print(letters_sorted)
