def move_zeros_extra_list_no_return(lst):
     '''lst -> None
        Move zeros from lst to the end
        using a temporary list  
        Precondtion: lst is a list of numbers
     '''
     tmp=[0]*len(lst) #tmp is filled with zeros
     index_tmp=0
     for i in range(len(lst)):
          if(lst[i]!=0):
               tmp[index_tmp]=lst[i]
               index_tmp=index_tmp+1
    
     # we copy elements of tmp into lst
     for i in range (len(lst)):
          lst[i]=tmp[i]

     # note that without return we can not lst directly
     # we caqn not use lst=tmp[:] !!!
     # because it changes the reference lst not x

x = [1, 0, 3, 0, 0, 5, 7] 
print(x)
move_zeros_extra_list_no_return(x)
print(x)

