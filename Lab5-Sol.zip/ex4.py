import math
def calculateStandarddeviation(x):
    m = 0
    for i in x:
      m = m + i
    m = m / len(x)
    s = 0
    for i in x:
      s = s + math.pow((i-m),2)
    standardDeviation = math.sqrt(s/(len(x)-1)); 
    return standardDeviation

ch = input('Please enter a list of values separated by commas: ')
l1 = list(eval(ch))
deviation = calculateStandarddeviation(l1)
print("The standard deviation is:", deviation)
 
