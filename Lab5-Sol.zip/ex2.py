def statistics(x):
    m = 0
    max = x[0]
    min = x[0]
    s = []
    for i in x:
      m = m + i
      if max < i:
        max = i
      if min > i:
        min = i
    m = m / len(x)
    s.append(m)
    s.append(max)
    s.append(min)
    return s

ch = input('Please enter a list of values separated by commas: ')
l1 = list(eval(ch))
print(l1)
l2 = statistics(l1)
print("The statistics are:")
print("The average:",l2[0]) 
print("The maximum:",l2[1]) 
print("The mimimum:",l2[2]) 
