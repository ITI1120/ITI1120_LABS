def calculateAverage(x):
   m = 0
   for i in x:
      m = m + i
   return m / len(x)

ch = input('Please enter a list of values separated by commas: ')
l1 = list(eval(ch))
print(l1)
print("The average is:",calculateeAverage(l1)) 
