import math

def calculateDistances (v):
    dist = []
    g = 9.8                     # Constant:  gravity 
    degToRad = math.pi / 180.0   # Constant:  degres -> radians
    nbrAngles = 10              # Constant: numbers of angles    
    theta = 0
    while  theta <= 90 :
      thetaRad = degToRad * theta
      dist.append(2.0 * v * v * math.cos(thetaRad) * math.sin(thetaRad) / g)
      theta = theta + 10
    return dist

speed = float(input('Please. provide the speed (m/s): '))
distances = calculateDistances(speed)
index = 0
while index < len(distances): 
      theta = index * 10
      print("For the angle",theta," degres, the ball travels parcourt",distances[index]," meters")
      index +=1
      
