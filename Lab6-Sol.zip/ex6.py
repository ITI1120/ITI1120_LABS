def code(s):
     '''(str)->str
      Returns a new coded chain
      '''
     s_code=''
     for i in range(0,len(s)-1,2):
          s_code=s_code+s[i+1]+s[i]
     if(len(s)%2==1): # if len(s) is odd, we add the last letter
          s_code=s_code + s[len(s)-1]
     return s_code



s1 = input("Please provide a character chain ")
print(code(s1))






