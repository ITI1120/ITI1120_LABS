def spaces(s):
   '''(str)->str
      Returns a new chain with spaces
   '''
   index = 0
   nS = ""
   while (index < len(s)):
     nS = nS + s[index] + ' '
     index = index + 1
   nS = nS.strip()
   return nS

def spaces_v1(s):
     '''(str)->str
      Returns a new chain with spaces
      '''
     s_emph=''
     for char in s:
          s_emph=s_emph+char+' '
     s_emph=s_emph[0:len(s_emph)-1]
     return s_emph

#s = input("Please provide a character chain: ")
#print(spaces(s),"--", sep='')
#print(spaces_v1(s),"--", sep='')




