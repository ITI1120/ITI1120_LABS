def count(s, c):
   count = 0
   index = 0
   while (index < len(s)):
     if (s[index] == c):
        count += 1
     index = index + 1
   return count

#def count(s, c):
#   return s.count(c)

s = input("Please provide a character chain: ")

print(count(s,'a'))






