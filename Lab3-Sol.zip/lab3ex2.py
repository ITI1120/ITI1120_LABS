temp = int( input("What is the temperature? "))

if temp >= 80.0:
  numAct = 1
elif temp >= 60.0 and temp < 80.0: 
  numAct = 2
elif temp >= 40.0 and temp < 60.0: 
  numAct = 3
else: 
  numAct = 4
    
if numAct == 1: 
  print("The recommended activity is swimming")
elif numAct == 2: 
  print("The recommended activity is soccer")
elif numAct == 3: 
  print("The recommended activity is volleyball")
elif(numAct == 4):
  print("The recommended activity is skying")




