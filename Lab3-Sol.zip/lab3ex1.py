age = int( input("What is your age? "))

accepté = 18 <= age <=55

if accepted :
 print("Transaction accepted")
else: 
 print("Transaction refused")
