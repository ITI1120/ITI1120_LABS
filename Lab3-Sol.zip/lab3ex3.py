ent = int( input("Enter an integer: "))

if ent%2==0 and ent%3==0 :
  divisibleBy2By3 = 2
elif ent%2==0 or ent%3==0: 
  divisibleBy2By3 = 1
else:
  divisibleBy2By3 = 0
     
if (divisibleBy2By3 == 0) :
  print("The integer ", ent, " is not divisible neither by 2 nor by 3")
if(divisibleBy2By3 == 1): 
  print("The integer ", ent, " is divisible by 2 or by 3")
if(divisibleBy2By3 == 2): 
  print("The integer ", ent, " is divisible by 2 and by 3")




